### Problem Set 2: Poetic Walks

The purpose of this problem set is to practice designing, testing, and implementing abstract data types. 
This problem set focuses on implementing mutable types where the specifications are provided to you; 
the next problem set will focus on immutable types where you must choose specifications.


